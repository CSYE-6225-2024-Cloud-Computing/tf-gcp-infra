import os
import requests
import base64
import json
import functions_framework
import sqlalchemy
import uuid
from datetime import datetime, timedelta


MAILGUN_API_KEY = os.getenv("MAILGUN_API_KEY", "4de658fabd37ad41a0cc1666f49e8e51-f68a26c9-ab63ee66")
YOUR_DOMAIN_NAME = os.getenv("YOUR_DOMAIN_NAME", "sjaiswal.me")
db_host = os.getenv("DB_HOST", "10.247.0.2")
db_user = os.getenv("DB_USERNAME", "webapp")  # e.g. 'my-db-user'
db_pass = os.getenv("DB_PASSWORD", "-i7GP4gDim-Q-rdc")  # e.g. 'my-db-password'
db_name = os.getenv("DB_NAME", "webapp")  # e.g. 'my-database'
db_port = os.getenv("DB_PORT", "5432")  # e.g. 5432

def env_vars(request):
    return os.environ.get("DB_PASSWORD", "-p7GP4gDim-Q-rdc")


# Connect to DB
def connect_tcp_socket() -> sqlalchemy.engine.base.Engine:
    """Initializes a TCP connection pool for a Cloud SQL instance of Postgres."""
    # [END cloud_sql_postgres_sqlalchemy_connect_tcp]
    connect_args = {}

    # [START cloud_sql_postgres_sqlalchemy_connect_tcp]
    pool = sqlalchemy.create_engine(
        # Equivalent URL:
        # postgresql+pg8000://<db_user>:<db_pass>@<db_host>:<db_port>/<db_name>
        sqlalchemy.engine.url.URL.create(
            drivername="postgresql+pg8000",
            username=db_user,
            password=db_pass,
            host=db_host,
            port=db_port,
            database=db_name,
        ),
        connect_args=connect_args,
        pool_size=5,
        max_overflow=2,
        pool_timeout=30,  # 30 seconds
        pool_recycle=1800,  # 30 minutes
    )
    return pool


# Send Email
def verification_email(user_email: str, db: sqlalchemy.engine.base.Engine):
    token_id = str(uuid.uuid4())
    current_timestamp = datetime.now()
    expires_timestamp = current_timestamp + timedelta(minutes=2)
    stmt1 = sqlalchemy.text("INSERT INTO public.logs VALUES (:token_id, :username, :email_sent_status, :current_timestamp, :expires_timestamp ) RETURNING *;")
    try:
        with db.connect() as conn:
            conn.execute(stmt1, parameters={"token_id": token_id,"username": user_email, "email_sent_status": "Failed", "current_timestamp":current_timestamp, "expires_timestamp":expires_timestamp })
            conn.commit()
            verification_link = f"https://{YOUR_DOMAIN_NAME}/v1/user/verify_email?token_id={token_id}"
            response = requests.post(
                                    f"https://api.mailgun.net/v3/{YOUR_DOMAIN_NAME}/messages",
                                    auth=("api", MAILGUN_API_KEY),
                                    data={  "from": f"Verify User <mailgun@{YOUR_DOMAIN_NAME}>",
                                            "to": [f"{user_email}", f"YOU@{YOUR_DOMAIN_NAME}"],
                                            "subject": "Account Verification",
                                            "text": f"""
                                                    You're almost there!

                                                    We just need to verify your email address to complete your registration.
                                                    Verify Your Email using this link {verification_link}

                                                    After activation, you can login into account
                                                    If you have any questions or need help, please visit our support page.

                                                    ~ ⁠Your friends at CSYE
                                                    """}
                                    )
        if response.status_code == 200:
            print("Verification Link sent successfully!")
            with db.connect() as conn:
                stmt3 = sqlalchemy.text("UPDATE public.logs SET email_sent_status = 'Passed' WHERE token_id = :token_id;")
                conn.execute(stmt3, parameters={"token_id": token_id})
                conn.commit()
        else:
            print(f"Failed to send verification email to {user_email}")
    except Exception as e:
        print(e)



# Triggered from a message on a Cloud Pub/Sub topic.
@functions_framework.cloud_event
def verify_useremail(cloud_event):
    print(f"========Start of Code===========")
    # Read messages
    user_details = json.loads(base64.b64decode(cloud_event.data["message"]["data"]).decode('utf-8'))
    print(f"The User Email ID is {user_details['username']}")
    # Connect to DB
    db = connect_tcp_socket()
    # Send Email
    verification_email(user_details['username'], db)
    print(f"========End of Code===========")
